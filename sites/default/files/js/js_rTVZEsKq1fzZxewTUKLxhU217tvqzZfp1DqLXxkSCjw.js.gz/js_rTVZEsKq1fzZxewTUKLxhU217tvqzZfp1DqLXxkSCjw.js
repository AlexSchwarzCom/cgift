/* Source and licensing information for the line(s) below can be found at http://localhost:8888/48specials/modules/inline_entity_form/js/inline_entity_form.js. */
(function(n){Drupal.behaviors.inlineEntityForm={attach:function(n){},detach:function(n){}}})(jQuery);
/* Source and licensing information for the above line(s) can be found at http://localhost:8888/48specials/modules/inline_entity_form/js/inline_entity_form.js. */;
