/* Source and licensing information for the line(s) below can be found at http://localhost:8888/48specials/modules/linkit/js/linkit.js. */
(function(u,t,i){'use strict';t.linkit={}})(jQuery,Drupal,drupalSettings);
/* Source and licensing information for the above line(s) can be found at http://localhost:8888/48specials/modules/linkit/js/linkit.js. */